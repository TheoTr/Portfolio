Function Set-Speaker($Volume){$wshShell = new-object -com wscript.shell;1..50 | % {$wshShell.SendKeys([char]174)};1..$Volume | % {$wshShell.SendKeys([char]175)}}
##Sets volume to 1 tick = 2% of max volume
Set-Speaker -Volume 30
